package P1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Scanner;

public class Administracion {
	private final String JDBC_DRIVER= "com.mysql.cj.jdbc.Driver";
	private final String DB_URL= "jdbc:mysql://localhost:3306/cine";
	
	private final String USER= "root";
	private final String PASS= "Dan41019755Dan";
	
	private Connection conn=null;
	
	
	public void crearSala() {
		PreparedStatement stmt=null;
		
		try {
			Class.forName(JDBC_DRIVER);
			
			System.out.println("Connecting to database...");
			conn=DriverManager.getConnection(DB_URL,USER,PASS);
					
			System.out.println("Creating statement...");
			
			int nroSala=10;
			int idPelicula=1;
			String query="INSERT INTO Sala (idSalas,Pelicula_idPelicula) VALUES (?,?);";
			stmt = conn.prepareStatement(query);
			stmt.setInt(1, nroSala);
			stmt.setInt(2, idPelicula);
			
			this.ingresarPelicula(nroSala);
			
	        stmt.executeUpdate();
			
			stmt.close();
			conn.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(stmt!=null)
					stmt.close();
			}catch(SQLException se2) {
			}
			try {
				if(conn!=null)
					conn.close();
			}catch(SQLException se) {
				se.printStackTrace();
			}
		}
	}
	private void ingresarPelicula(int nroSala) {
		PreparedStatement stmt=null;
		
		try {
			Class.forName(JDBC_DRIVER);
			System.out.println("Connecting to database...");
			conn=DriverManager.getConnection(DB_URL,USER,PASS);
			
			int idPelicula=nroSala;
			String titulo="Avatar";
			String productor="James Cmeron";
			/***********/
			int h=2;
			int m=30;
			Time duracion=new Time(0);
			duracion.setHours(h);
			duracion.setMinutes(m);
			duracion.setSeconds(00);
			/***********/
			String idioma="Espa�ol";
			h=20;
			m=30;
			Time horario=new Time(0);
			horario.setHours(h);
			horario.setMinutes(m);
			horario.setSeconds(00);
			String genero="accion";
			String tipo="2D";
			int idCartelera=2; // CONSULTAR
			
			String query="INSERT INTO pelicula (idPelicula, titulo, productor, duracion, idioma, horarios, genero, tipo, Cartelera_idCartelera) VALUES(?,?,?,?,?,?,?,?,?);";
			
			stmt = conn.prepareStatement(query);
			
			stmt.setInt(1, idPelicula);
			stmt.setString(2, titulo);
			stmt.setString(3, productor);
			stmt.setTime(4, duracion);
			stmt.setString(5, idioma);
			stmt.setTime(6, horario);
			stmt.setString(7, genero);
			stmt.setString(8, tipo);
			stmt.setInt(9, idCartelera);
			
			stmt.executeUpdate();
			
			stmt.close();
			conn.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(stmt!=null)
					stmt.close();
			}catch(SQLException se2) {
			}
			try {
				if(conn!=null)
					conn.close();
			}catch(SQLException se) {
				se.printStackTrace();
			}
		}
		System.out.println("Se ha guardado la pelicula.");
	}
	
	public void modificarSala() {
		Scanner ingresoN=new Scanner(System.in);
		
	}
}
