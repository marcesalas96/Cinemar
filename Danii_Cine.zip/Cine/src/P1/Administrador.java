package P1;

import java.util.Scanner;

public class Administrador extends Usuario{
	private Administracion operaciones;
	
	public Administrador(String nombre, String apellido, int edad, String correo, String contrase�a) {
		super(nombre,apellido,edad,correo,contrase�a);
		this.operaciones=new Administracion();
	}
	
	public void menuDeOperaciones() {
		int op;
		Scanner opcion=new Scanner(System.in);
		do {
			this.menu();
			op=opcion.nextInt();
			switch(op) {
			case 1:
				
				break;
			case 2:
				
				break;
			case 3:
				
				break;
			case 4:
				
				break;
			case 5:
				
				break;
			case 6:
				
				break;
			default:
				System.out.println("Saliendo del menu...");
				break;
			}
		}while(op!=0);
	}
	public void menu() {
		System.out.println("1- Ver las revservas de los clientes");
		System.out.println("2- Ver las revservas de un cliente");
		System.out.println("3- Crear una sala con la pelicula");
		System.out.println("4- Modificar una sala");
		System.out.println("5- Eliminar una sala");
		System.out.println("6- Modificar descuentos");
		System.out.println("0- Salir");
	}
}
