package P1;

public class Cliente extends Usuario {
	
	
	public Cliente(String nombre, String apellido, int edad, String correo, String contrase�a) {
		super(nombre,apellido,edad,correo,contrase�a);
	}
	
	
}
