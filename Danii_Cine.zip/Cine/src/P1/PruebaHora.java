package P1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import java.util.Calendar;

public class PruebaHora {
	private final String JDBC_DRIVER= "com.mysql.cj.jdbc.Driver";
	private final String DB_URL= "jdbc:mysql://localhost:3306/horario";
	
	private final String USER= "root";
	private final String PASS= "Dan41019755Dan";
	
	private Connection conn=null;
	
	public void crearHora() {
		PreparedStatement stmt=null;
		
		try {
			Class.forName(JDBC_DRIVER);
			
			System.out.println("Connecting to database...");
			conn=DriverManager.getConnection(DB_URL,USER,PASS);
					
			System.out.println("Creating statement...");
			
			Time horaa=new Time(0);
			
			horaa.setHours(1);
			horaa.setMinutes(45);
			horaa.setSeconds(00);
			
			stmt = conn.prepareStatement("INSERT INTO Hora (id,horario) VALUES ("+2+",'"+horaa+"');");
	        stmt.executeUpdate();
			
			stmt.close();
			conn.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(stmt!=null)
					stmt.close();
			}catch(SQLException se2) {
			}
			try {
				if(conn!=null)
					conn.close();
			}catch(SQLException se) {
				se.printStackTrace();
			}
		}
	}
}
