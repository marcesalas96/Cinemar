package P1;
import java.sql.*;

public class Registro extends Usuario {
	
	
	public Registro(String nombre, String apellido, int edad, String correo, String contrase�a) {
		super(nombre,apellido,edad,correo,contrase�a);
	}
	
	public void nuevoCliente() {
		final String JDBC_DRIVER= "com.mysql.cj.jdbc.Driver";
		final String DB_URL= "jdbc:mysql://localhost:3306/cine";
		
		final String USER= "root";
		final String PASS= "Dan41019755Dan";
		
		Connection conn=null;
		//Statement stmt=null;
		PreparedStatement stmt=null;
		
		try {
			Class.forName(JDBC_DRIVER);
			
			System.out.println("Connecting to database...");
			conn=DriverManager.getConnection(DB_URL,USER,PASS);
					
			System.out.println("Creating statement...");
			
			//stmt= conn.createStatement();
			String nombre="Daniel";
			String apellido="Calle";
			int edad=24;
			String correo="alejandrodanielcalle@gmail.com";
			String contra="asdfs";
			
			//stmt = conn.prepareStatement("INSERT INTO Usuario (id_Usuario,nombre,apellido,edad,correo,contrase�a)  VALUES("+1+",'"+nombre+"','"+apellido+"',"+edad+",'"+correo+"','"+contra+"');");
			//stmt.executeUpdate();
			
			stmt = conn.prepareStatement("INSERT INTO Cliente (id,tarjeta) VALUES ("+1+","+0+");");
	        stmt.executeUpdate();
			
	        
	        /*
			String sql;
			sql="insert into Usuario values(1,'Danel','Calle',25,'alejandrodanielcalle@gmail.com','d123d');";
			ResultSet rs=stmt.executeQuery(sql);
			sql="INSERT INTO Cliente values (1,1);";
			rs=stmt.executeQuery(sql);
			*/
			
			/*
			sql="SELECT Name, Code, Population FROM country";
			ResultSet rs= stmt.executeQuery(sql);
			
			while(rs.next()) {
				
				int population = rs.getInt("Population");
				String Name= rs.getString("Name");
				String CountryCode= rs.getString("Code");
				
				System.out.println("Pai: "+Name);
				System.out.println(", Codigo Pais: "+CountryCode);
				System.out.println(", Poblacion: "+population+" habitantes");
			}
			*/
			//rs.close();
			stmt.close();
			conn.close();
		}catch(SQLException se) {
			se.printStackTrace();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if(stmt!=null)
					stmt.close();
			}catch(SQLException se2) {
			}
			try {
				if(conn!=null)
					conn.close();
			}catch(SQLException se) {
				se.printStackTrace();
			}
		}
		System.out.println("Goodbye");
	}
}
