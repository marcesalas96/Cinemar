package P1;

public class Test {

	public static void main(String[] args) {
		/*
		Registro rtest=new Registro("d","a",4,"j","l");
		rtest.nuevoCliente();
		*/
		PruebaHora p=new PruebaHora();
		p.crearHora();
		
		if(login instanceof cliente) {
			
		}
		else {
			
		}
	}

}
